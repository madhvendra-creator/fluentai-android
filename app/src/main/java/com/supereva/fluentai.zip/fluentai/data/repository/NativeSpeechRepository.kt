package com.supereva.fluentai.data.repository

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.supereva.fluentai.domain.repository.SpeechRepository
import com.supereva.fluentai.domain.repository.SpeechResult
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onStart
import java.io.File

class NativeSpeechRepository(
    private val context: Context
) : SpeechRepository {

    private var speechRecognizer: SpeechRecognizer? = null
    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val audioManager by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
    }

    private val _results = MutableSharedFlow<SpeechResult>(
        replay = 0,
        extraBufferCapacity = 64,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    @Volatile private var isRecognitionActive = false
    @Volatile private var currentLanguage = "en-US"

    // ── SINGLE RULE: mute before start, unmute only in onReadyForSpeech ──

    private val streamsToMute = listOf(
        android.media.AudioManager.STREAM_SYSTEM,
        android.media.AudioManager.STREAM_NOTIFICATION,
        android.media.AudioManager.STREAM_MUSIC,
        android.media.AudioManager.STREAM_RING
    )

    private fun muteAll() {
        streamsToMute.forEach { stream ->
            try {
                audioManager.adjustStreamVolume(
                    stream, android.media.AudioManager.ADJUST_MUTE, 0
                )
            } catch (_: Exception) {}
        }
    }

    private fun unmuteAll() {
        streamsToMute.forEach { stream ->
            try {
                audioManager.adjustStreamVolume(
                    stream, android.media.AudioManager.ADJUST_UNMUTE, 0
                )
            } catch (_: Exception) {}
        }
    }

    private fun getOrCreateRecognizer(): SpeechRecognizer? {
        if (speechRecognizer != null) return speechRecognizer
        if (!SpeechRecognizer.isRecognitionAvailable(context)) return null

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {

                override fun onReadyForSpeech(params: Bundle?) {
                    isRecognitionActive = true
                    // THIS IS THE ONLY PLACE WE UNMUTE
                    unmuteAll()
                }

                override fun onBeginningOfSpeech() {}

                override fun onRmsChanged(rmsdB: Float) {
                    _results.tryEmit(SpeechResult.VolumeUpdate(rmsdB))
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    // Mute the stop beep — fires before onResults/onError
                    muteAll()
                }

                override fun onError(error: Int) {
                    isRecognitionActive = false
                    // Emit ALL errors to ViewModel — let ViewModel decide to restart
                    // Do NOT auto-restart here — causes double-restart race conditions
                    _results.tryEmit(SpeechResult.Error(getErrorText(error)))
                }

                override fun onResults(results: Bundle?) {
                    isRecognitionActive = false
                    val matches = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        _results.tryEmit(SpeechResult.Final(matches[0]))
                    } else {
                        // Treat empty results like no-match
                        _results.tryEmit(SpeechResult.Error("No match"))
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        _results.tryEmit(SpeechResult.Partial(matches[0]))
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        return speechRecognizer
    }

    private fun buildIntent(language: String): Intent =
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language)
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, true)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 4000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 300L)
        }

    // Called once when user taps green mic button
    override fun startListening(language: String): Flow<SpeechResult> {
        currentLanguage = language
        return _results
            .onStart { startRecognition(language) }
            .onCompletion {
                mainHandler.post {
                    if (isRecognitionActive) {
                        speechRecognizer?.cancel()
                        isRecognitionActive = false
                    }
                    unmuteAll()
                }
            }
    }

    // Called by ViewModel to restart after Final/Error
    fun restartListening(language: String = "en-US") {
        currentLanguage = language
        mainHandler.post { startRecognition(language) }
    }

    // Called by ViewModel for trash/delete button — cancel first, then restart
    fun forceRestartListening(language: String = "en-US") {
        currentLanguage = language
        mainHandler.post {
            if (isRecognitionActive) {
                speechRecognizer?.cancel()
                isRecognitionActive = false
            }
            // Small delay to let cancel settle before restarting
            mainHandler.postDelayed({ startRecognition(language) }, 150)
        }
    }

    // Called by old code paths — delegate to restartListening
    fun fireStartListening(language: String = "en-US") {
        restartListening(language)
    }

    // Core start — ALWAYS mutes before starting, unmute happens in onReadyForSpeech
    private fun startRecognition(language: String) {
        val recognizer = getOrCreateRecognizer() ?: run {
            _results.tryEmit(SpeechResult.Error("Speech recognition not available"))
            return
        }
        // Cancel any existing session first
        if (isRecognitionActive) {
            recognizer.cancel()
            isRecognitionActive = false
        }
        // ALWAYS mute before starting — onReadyForSpeech will unmute
        muteAll()
        recognizer.startListening(buildIntent(language))
    }

    override fun stopListening() {
        muteAll()
        mainHandler.post {
            if (isRecognitionActive) {
                speechRecognizer?.stopListening()
                isRecognitionActive = false
            }
            // Delay then unmute since we stopped intentionally
            mainHandler.postDelayed({ unmuteAll() }, 400)
        }
    }

    override fun release() {
        mainHandler.post {
            if (isRecognitionActive) {
                speechRecognizer?.cancel()
                isRecognitionActive = false
            }
            speechRecognizer?.destroy()
            speechRecognizer = null
            unmuteAll()
        }
    }

    @Deprecated("Use startListening() for real-time recognition")
    override suspend fun transcribeAudio(file: File): String {
        throw UnsupportedOperationException("Not supported")
    }

    private fun getErrorText(errorCode: Int): String = when (errorCode) {
        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
        SpeechRecognizer.ERROR_CLIENT -> "Client side error"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Insufficient permissions"
        SpeechRecognizer.ERROR_NETWORK -> "Network error"
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
        SpeechRecognizer.ERROR_NO_MATCH -> "No match"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "RecognitionService busy"
        SpeechRecognizer.ERROR_SERVER -> "Error from server"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech input"
        else -> "Didn't understand, please try again."
    }
}
